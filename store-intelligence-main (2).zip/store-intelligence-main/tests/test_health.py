import pytest


@pytest.mark.asyncio
async def test_health_returns_healthy_when_no_stores(client):
    resp = await client.get("/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "healthy"
    assert data["database"] == "connected"
    assert data["stores"] == []
    assert "checked_at" in data
    assert "version" in data


@pytest.mark.asyncio
async def test_health_response_shape(client):
    resp = await client.get("/health")
    data = resp.json()
    assert set(data.keys()) >= {"status", "version", "database", "stores", "checked_at"}
