import uuid
import pytest

STORE = "STORE_METRICS_001"
CAM   = "CAM_01"


def _ev(event_type, visitor_id, **kw) -> dict:
    base = {
        "event_id":   str(uuid.uuid4()),
        "store_id":   STORE,
        "camera_id":  CAM,
        "visitor_id": visitor_id,
        "event_type": event_type,
        "timestamp":  "2026-06-03T09:00:00Z",
        "confidence": 0.85,
        "is_staff":   False,
        "dwell_ms":   0,
        "zone_id":    None,
        "metadata":   None,
    }
    base.update(kw)
    return base


@pytest.mark.asyncio
async def test_metrics_empty_store(client):
    resp = await client.get(f"/stores/{STORE}/metrics")
    assert resp.status_code == 200
    data = resp.json()
    assert data["store_id"] == STORE
    assert data["unique_visitors"] == 0
    assert data["conversion_rate"] == 0.0
    assert data["current_queue_depth"] == 0
    assert data["abandonment_rate"] == 0.0


@pytest.mark.asyncio
async def test_metrics_unique_visitors(client):
    events = [
        _ev("ENTRY", "VIS_AAA"),
        _ev("ENTRY", "VIS_BBB"),
        _ev("ENTRY", "VIS_AAA"),  # duplicate visitor — should not double count
    ]
    await client.post("/events/ingest", json=events)
    resp = await client.get(f"/stores/{STORE}/metrics")
    assert resp.json()["unique_visitors"] == 2


@pytest.mark.asyncio
async def test_metrics_conversion_rate(client):
    vis = "VIS_CONV"
    events = [
        _ev("ENTRY", vis),
        _ev("BILLING_QUEUE_JOIN", vis,
            zone_id="BILLING",
            metadata={"queue_depth": 2, "sku_zone": None, "session_seq": 2}),
    ]
    await client.post("/events/ingest", json=events)
    resp = await client.get(f"/stores/{STORE}/metrics")
    data = resp.json()
    assert data["unique_visitors"] >= 1
    assert data["conversion_rate"] > 0.0


@pytest.mark.asyncio
async def test_funnel_empty_store(client):
    resp = await client.get(f"/stores/{STORE}/funnel")
    assert resp.status_code == 200
    data = resp.json()
    assert data["store_id"] == STORE
    assert len(data["stages"]) == 4
    assert data["stages"][0]["stage"] == "ENTRY"
    assert data["stages"][0]["drop_off_pct"] == 0.0


@pytest.mark.asyncio
async def test_heatmap_empty_store(client):
    resp = await client.get(f"/stores/{STORE}/heatmap")
    assert resp.status_code == 200
    data = resp.json()
    assert data["store_id"] == STORE
    assert data["zones"] == []


@pytest.mark.asyncio
async def test_heatmap_with_zone_visits(client):
    events = [
        _ev("ENTRY",      "VIS_HM1"),
        _ev("ZONE_ENTER", "VIS_HM1", zone_id="ZONE_A"),
        _ev("ZONE_ENTER", "VIS_HM1", zone_id="ZONE_B"),
        _ev("ZONE_DWELL", "VIS_HM1", zone_id="ZONE_A", dwell_ms=35000),
    ]
    await client.post("/events/ingest", json=events)
    resp = await client.get(f"/stores/{STORE}/heatmap")
    data = resp.json()
    assert len(data["zones"]) >= 1
    zone_ids = [z["zone_id"] for z in data["zones"]]
    assert "ZONE_A" in zone_ids


@pytest.mark.asyncio
async def test_anomalies_empty_store(client):
    resp = await client.get(f"/stores/{STORE}/anomalies")
    assert resp.status_code == 200
    data = resp.json()
    assert data["store_id"] == STORE
    assert isinstance(data["anomalies"], list)


@pytest.mark.asyncio
async def test_staff_events_excluded_from_metrics(client):
    events = [
        _ev("ENTRY", "VIS_STAFF1", is_staff=True),
        _ev("ENTRY", "VIS_CUST1",  is_staff=False),
    ]
    await client.post("/events/ingest", json=events)
    resp = await client.get(f"/stores/{STORE}/metrics")
    assert resp.json()["unique_visitors"] == 1
