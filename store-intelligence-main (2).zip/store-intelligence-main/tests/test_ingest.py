import uuid
from datetime import datetime, timezone

import pytest

STORE = "STORE_TEST_001"
CAM   = "CAM_01"


def _entry_event(**overrides) -> dict:
    base = {
        "event_id":   str(uuid.uuid4()),
        "store_id":   STORE,
        "camera_id":  CAM,
        "visitor_id": f"VIS_{uuid.uuid4().hex[:6]}",
        "event_type": "ENTRY",
        "timestamp":  "2026-06-01T09:00:00Z",
        "confidence": 0.91,
        "is_staff":   False,
        "dwell_ms":   0,
        "zone_id":    None,
        "metadata":   None,
    }
    base.update(overrides)
    return base


def _billing_event(**overrides) -> dict:
    base = _entry_event(
        event_type="BILLING_QUEUE_JOIN",
        zone_id="BILLING",
        metadata={"queue_depth": 3, "sku_zone": None, "session_seq": 2},
    )
    base.update(overrides)
    return base


@pytest.mark.asyncio
async def test_ingest_single_entry_event(client):
    resp = await client.post("/events/ingest", json=[_entry_event()])
    assert resp.status_code == 200
    data = resp.json()
    assert data["accepted"] == 1
    assert data["rejected"] == 0
    assert data["errors"] == []


@pytest.mark.asyncio
async def test_ingest_idempotent(client):
    event = _entry_event()
    resp1 = await client.post("/events/ingest", json=[event])
    resp2 = await client.post("/events/ingest", json=[event])
    assert resp1.status_code == 200
    assert resp2.status_code == 200
    # Second call should have 0 accepted (duplicate)
    assert resp2.json()["accepted"] == 0
    assert resp2.json()["rejected"] == 0


@pytest.mark.asyncio
async def test_ingest_batch_multiple_events(client):
    events = [_entry_event() for _ in range(5)]
    resp = await client.post("/events/ingest", json=events)
    assert resp.status_code == 200
    assert resp.json()["accepted"] == 5


@pytest.mark.asyncio
async def test_ingest_rejects_missing_zone_id_for_zone_event(client):
    event = _entry_event(event_type="ZONE_ENTER", zone_id=None)
    resp  = await client.post("/events/ingest", json=[event])
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_ingest_billing_queue_join_requires_queue_depth(client):
    event = _entry_event(
        event_type="BILLING_QUEUE_JOIN",
        zone_id="BILLING",
        metadata={"sku_zone": None, "session_seq": 1},  # missing queue_depth
    )
    resp = await client.post("/events/ingest", json=[event])
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_ingest_billing_event_valid(client):
    resp = await client.post("/events/ingest", json=[_billing_event()])
    assert resp.status_code == 200
    assert resp.json()["accepted"] == 1


@pytest.mark.asyncio
async def test_ingest_rejects_naive_timestamp(client):
    event = _entry_event(timestamp="2026-06-01T09:00:00")  # no timezone
    resp  = await client.post("/events/ingest", json=[event])
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_ingest_empty_batch(client):
    resp = await client.post("/events/ingest", json=[])
    assert resp.status_code == 200
    assert resp.json()["accepted"] == 0
