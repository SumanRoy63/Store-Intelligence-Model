from functools import lru_cache
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # Application
    app_name: str = "Store Intelligence API"
    app_version: str = "1.0.0"
    environment: str = "development"
    log_level: str = "INFO"

    # Database
    database_url: str = "sqlite+aiosqlite:///./data/store_intelligence.db"

    # Business constants
    reentry_window_seconds: int = 300
    dwell_emit_interval_seconds: int = 30
    pos_correlation_window_seconds: int = 300
    stale_feed_threshold_seconds: int = 600
    dead_zone_threshold_seconds: int = 1800
    baseline_conversion_rate: float = 0.35
    heatmap_min_sessions: int = 20
    ingest_max_batch_size: int = 500

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache
def get_settings() -> Settings:
    return Settings()
