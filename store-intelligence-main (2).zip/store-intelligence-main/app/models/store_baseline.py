from datetime import datetime
from sqlalchemy import DateTime, Float, String
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class StoreBaseline(Base):
    """
    Per-store baseline metrics used by /anomalies.
    Seeded with a default conversion rate; updated as real data accumulates.
    """

    __tablename__ = "store_baselines"

    store_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    baseline_conversion_rate: Mapped[float] = mapped_column(Float, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=datetime.utcnow,
    )

    def __repr__(self) -> str:
        return (
            f"<StoreBaseline store={self.store_id} "
            f"conversion_rate={self.baseline_conversion_rate}>"
        )
