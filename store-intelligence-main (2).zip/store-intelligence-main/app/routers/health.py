import logging
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, Depends
from sqlalchemy import select, func, text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.database import get_db
from app.models.event import Event
from app.schemas.events import HealthResponse, StoreFeedStatus

logger = logging.getLogger(__name__)
router = APIRouter(tags=["health"])
settings = get_settings()


@router.get(
    "/health",
    response_model=HealthResponse,
    summary="Service health check",
    description=(
        "Returns database connectivity, per-store feed status (OK / STALE_FEED / NO_DATA), "
        "and overall service status (healthy / degraded)."
    ),
)
async def health_check(
    db: AsyncSession = Depends(get_db),
) -> HealthResponse:
    now = datetime.now(tz=timezone.utc)
    db_status = "connected"
    store_statuses: list[StoreFeedStatus] = []

    try:
        # Verify DB is reachable
        await db.execute(text("SELECT 1"))

        # Get all known stores and their last event timestamp
        result = await db.execute(
            select(
                Event.store_id,
                func.max(Event.timestamp).label("last_event_at"),
            ).group_by(Event.store_id)
        )
        rows = result.fetchall()

        stale_threshold = timedelta(seconds=settings.stale_feed_threshold_seconds)

        for row in rows:
            last_event_at = row.last_event_at
            if last_event_at is None:
                status = "NO_DATA"
            else:
                if last_event_at.tzinfo is None:
                    last_event_at = last_event_at.replace(tzinfo=timezone.utc)
                lag = now - last_event_at
                status = "OK" if lag <= stale_threshold else "STALE_FEED"

            store_statuses.append(StoreFeedStatus(
                store_id=row.store_id,
                last_event_at=last_event_at,
                status=status,
            ))

    except SQLAlchemyError as exc:
        logger.error("health_check_db_error", extra={"error": str(exc)})
        db_status = "unavailable"

    overall = "healthy"
    if db_status == "unavailable":
        overall = "degraded"
    elif any(s.status == "STALE_FEED" for s in store_statuses):
        overall = "degraded"

    return HealthResponse(
        status=overall,
        version=settings.app_version,
        database=db_status,
        stores=store_statuses,
        checked_at=now,
    )
