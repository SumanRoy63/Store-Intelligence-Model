import logging
from typing import Annotated

from fastapi import APIRouter, Depends, Path
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.services.metrics import compute_metrics
from app.services.funnel import compute_funnel
from app.services.heatmap import compute_heatmap
from app.services.anomalies import detect_anomalies
from app.schemas.events import (
    StoreAnomalies, StoreFunnel, StoreHeatmap, StoreMetrics,
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/stores/{store_id}", tags=["stores"])


@router.get(
    "/metrics",
    response_model=StoreMetrics,
    summary="Real-time store metrics",
    description=(
        "Unique visitors, conversion rate, average dwell per zone, "
        "current queue depth, and abandonment rate. "
        "Staff events excluded. Always real-time — not cached."
    ),
)
async def get_metrics(
    store_id: Annotated[str, Path(description="Store ID, e.g. STORE_BLR_002")],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> StoreMetrics:
    return await compute_metrics(db, store_id)


@router.get(
    "/funnel",
    response_model=StoreFunnel,
    summary="Conversion funnel",
    description=(
        "Entry → Zone Visit → Billing Queue → Purchase with counts and drop-off %. "
        "Session is the unit. Re-entries do not double-count a visitor."
    ),
)
async def get_funnel(
    store_id: Annotated[str, Path()],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> StoreFunnel:
    return await compute_funnel(db, store_id)


@router.get(
    "/heatmap",
    response_model=StoreHeatmap,
    summary="Zone visit heatmap",
    description=(
        "Zone visit frequency and average dwell, normalised 0–100 for grid rendering. "
        "data_confidence=false when fewer than 20 sessions contributed to a zone."
    ),
)
async def get_heatmap(
    store_id: Annotated[str, Path()],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> StoreHeatmap:
    return await compute_heatmap(db, store_id)


@router.get(
    "/anomalies",
    response_model=StoreAnomalies,
    summary="Active anomalies",
    description=(
        "Detects: BILLING_QUEUE_SPIKE, CONVERSION_DROP vs 7-day baseline, "
        "DEAD_ZONE (no visits in 30 min), STALE_FEED. "
        "Each anomaly has severity (INFO/WARN/CRITICAL) and suggested_action."
    ),
)
async def get_anomalies(
    store_id: Annotated[str, Path()],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> StoreAnomalies:
    return await detect_anomalies(db, store_id)
