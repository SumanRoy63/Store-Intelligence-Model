"""
pipeline/detect.py

YOLOv8n person detection on CCTV video clips.
Yields FrameDetections (one per sampled frame) to tracker.py.
"""

import argparse
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Generator

import cv2
import numpy as np
from ultralytics import YOLO

logger = logging.getLogger(__name__)

_PERSON_CLASS  = 0          # COCO class index for "person"
_MODEL_WEIGHTS = "yolov8n.pt"


@dataclass(slots=True)
class Detection:
    """Single person detection from one video frame."""
    frame_number: int
    x1: float
    y1: float
    x2: float
    y2: float
    confidence: float

    @property
    def xyxy(self) -> np.ndarray:
        return np.array([self.x1, self.y1, self.x2, self.y2], dtype=np.float32)

    @property
    def centroid(self) -> tuple[float, float]:
        return ((self.x1 + self.x2) / 2.0, (self.y1 + self.y2) / 2.0)

    @property
    def width(self) -> float:
        return self.x2 - self.x1

    @property
    def height(self) -> float:
        return self.y2 - self.y1

    @property
    def area(self) -> float:
        return self.width * self.height


@dataclass
class FrameDetections:
    """All person detections from a single video frame."""
    frame_number: int
    timestamp_ms: float
    frame_width: int
    frame_height: int
    detections: list[Detection] = field(default_factory=list)

    @property
    def count(self) -> int:
        return len(self.detections)


def build_detector(
    weights: str = _MODEL_WEIGHTS,
    confidence_threshold: float = 0.25,
    iou_threshold: float = 0.45,
    device: str = "",
) -> YOLO:
    """
    Load YOLOv8n model with person-only class filter.

    conf=0.25  — low intentionally; spec requires confidence be passed through
                 so tracker/emitter can decide, not dropped silently here.
    iou=0.45   — NMS overlap threshold; keeps tightest box per person.
    classes=[0] — person only; filtered at inference time, not post-processing.
    """
    model = YOLO(weights)
    model.overrides["conf"]    = confidence_threshold
    model.overrides["iou"]     = iou_threshold
    model.overrides["classes"] = [_PERSON_CLASS]
    model.overrides["verbose"] = False
    if device:
        model.overrides["device"] = device
    logger.info("detector_loaded", extra={
        "weights": weights, "conf": confidence_threshold, "device": device or "auto"
    })
    return model


def _open_capture(video_path: Path) -> cv2.VideoCapture:
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise FileNotFoundError(f"Cannot open video file: {video_path}")
    return cap


def iter_detections(
    video_path: Path,
    model: YOLO,
    frame_stride: int = 1,
    max_frames: int | None = None,
) -> Generator[FrameDetections, None, None]:
    """
    Yield FrameDetections for every sampled frame.

    Empty frames ARE yielded so tracker.py can detect occlusion gaps.
    Coordinates are clamped to frame bounds (NMS can produce out-of-bounds
    boxes at image edges).
    """
    cap = _open_capture(video_path)
    fps          = cap.get(cv2.CAP_PROP_FPS) or 15.0
    frame_width  = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    logger.info("video_opened", extra={
        "path": str(video_path),
        "fps": fps,
        "resolution": f"{frame_width}x{frame_height}",
        "total_frames": total_frames,
        "frame_stride": frame_stride,
    })

    frame_number = 0
    processed    = 0

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break

            if frame_number % frame_stride == 0:
                timestamp_ms = cap.get(cv2.CAP_PROP_POS_MSEC)
                results      = model(frame, verbose=False)
                result       = results[0]

                frame_dets = FrameDetections(
                    frame_number=frame_number,
                    timestamp_ms=timestamp_ms,
                    frame_width=frame_width,
                    frame_height=frame_height,
                )

                if result.boxes is not None and len(result.boxes) > 0:
                    boxes    = result.boxes
                    xyxy_all = boxes.xyxy.cpu().numpy()
                    conf_all = boxes.conf.cpu().numpy()
                    cls_all  = boxes.cls.cpu().numpy()

                    for i in range(len(boxes)):
                        # Defensive guard — model.overrides should handle this
                        if int(cls_all[i]) != _PERSON_CLASS:
                            continue

                        x1 = max(0.0,              float(xyxy_all[i][0]))
                        y1 = max(0.0,              float(xyxy_all[i][1]))
                        x2 = min(float(frame_width),  float(xyxy_all[i][2]))
                        y2 = min(float(frame_height), float(xyxy_all[i][3]))

                        if x2 <= x1 or y2 <= y1:
                            continue

                        frame_dets.detections.append(Detection(
                            frame_number=frame_number,
                            x1=x1, y1=y1, x2=x2, y2=y2,
                            confidence=float(conf_all[i]),
                        ))

                yield frame_dets
                processed += 1

                if max_frames is not None and processed >= max_frames:
                    break

            frame_number += 1

    finally:
        cap.release()

    logger.info("video_processed", extra={
        "path": str(video_path),
        "frames_read": frame_number,
        "frames_processed": processed,
    })


def detect_clip(
    video_path: Path,
    weights: str = _MODEL_WEIGHTS,
    confidence_threshold: float = 0.25,
    iou_threshold: float = 0.45,
    frame_stride: int = 1,
    device: str = "",
    max_frames: int | None = None,
) -> Generator[FrameDetections, None, None]:
    """Convenience entry point: build detector then yield FrameDetections."""
    model = build_detector(
        weights=weights,
        confidence_threshold=confidence_threshold,
        iou_threshold=iou_threshold,
        device=device,
    )
    yield from iter_detections(
        video_path=video_path,
        model=model,
        frame_stride=frame_stride,
        max_frames=max_frames,
    )


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Run YOLOv8n person detection on a single video clip."
    )
    parser.add_argument("video",              type=Path)
    parser.add_argument("--weights",          default=_MODEL_WEIGHTS)
    parser.add_argument("--conf",             type=float, default=0.25)
    parser.add_argument("--iou",              type=float, default=0.45)
    parser.add_argument("--stride",           type=int,   default=1)
    parser.add_argument("--device",           default="")
    parser.add_argument("--max-frames",       type=int,   default=None)
    parser.add_argument("--log-level",        default="INFO",
                        choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(message)s",
    )

    total_dets   = 0
    total_frames = 0

    for fd in detect_clip(
        video_path=args.video,
        weights=args.weights,
        confidence_threshold=args.conf,
        iou_threshold=args.iou,
        frame_stride=args.stride,
        device=args.device,
        max_frames=args.max_frames,
    ):
        total_frames += 1
        total_dets   += fd.count

    print(
        f"\nDone. Frames processed: {total_frames} | "
        f"Total detections: {total_dets} | "
        f"Avg per frame: {total_dets / total_frames:.2f}" if total_frames else "0"
    )
