# DESIGN.md — Store Intelligence API

## Architecture Overview

Two independent components communicate only via HTTP:

**Detection pipeline** (`pipeline/`) runs offline against CCTV clip files.
YOLOv8n detects persons frame-by-frame; ByteTrack assigns persistent track IDs;
zone mapping classifies centroids into named zones; emit.py builds structured events
and batch-POSTs them to the API.

**Intelligence API** (`app/`) is a FastAPI service backed by SQLite (WAL mode).
Events are ingested, persisted, and analytics are computed on demand across 6 endpoints.
No message queue or streaming layer — HTTP batches are simple and sufficient at this scale.

```
CCTV Video
     │
     ▼
YOLOv8n Detection      (pipeline/detect.py)
     │
     ▼
ByteTrack Tracking     (pipeline/tracker.py)
     │
     ▼
Zone Mapping           (pipeline/zones.py)
     │
     ▼
Event Emission         (pipeline/emit.py)
     │
     ▼  POST /events/ingest
SQLite WAL
     │
 ┌───┼─────────────┬──────────────┐
 ▼   ▼             ▼              ▼
Metrics  Funnel  Heatmap  Anomalies
```

## Component Breakdown

| Component               | Responsibility                                      |
|-------------------------|-----------------------------------------------------|
| `pipeline/detect.py`    | Frame extraction + YOLOv8n inference                |
| `pipeline/tracker.py`   | ByteTrack + Re-ID + re-entry detection              |
| `pipeline/zones.py`     | Polygon zone mapping from layout.json               |
| `pipeline/emit.py`      | Event schema construction + batch POST to API       |
| `app/routers/`          | HTTP layer only — no business logic                 |
| `app/services/`         | All business logic                                  |
| `app/models/`           | SQLAlchemy ORM — Event + StoreBaseline              |
| `app/core/`             | Config, DB, logging middleware, error handlers      |

## Storage

SQLite with WAL journal mode. Chosen over PostgreSQL because:
1. The dataset is bounded (events from CCTV clips — thousands, not millions)
2. WAL mode provides concurrent reads alongside the single writer
3. Zero infrastructure — DB is a file in a Docker volume; single container
4. `docker compose up` starts everything with no second container

Indexes on `(store_id, timestamp)`, `(store_id, visitor_id)`, and
`(store_id, zone_id, timestamp)` cover every analytics query pattern.

## AI-Assisted Decisions

### 1. ByteTrack vs StrongSORT

AI suggested StrongSORT for better Re-ID accuracy given the re-entry requirement.

**Decision**: ByteTrack. Built into `ultralytics` (zero extra setup). Re-ID accuracy
is supplemented by IoU-based trajectory matching in `tracker.py`. Upgrading to
StrongSORT is a one-line tracker config change if accuracy needs improvement.

### 2. Rule-based zone classification vs VLM

AI suggested a VLM (Claude Vision / GPT-4V) for ambiguous zone boundaries.

**Decision**: Rule-based polygon mapping. `layout.json` already encodes explicit
zone polygons. Centroid-in-polygon is deterministic, fast, free, and debuggable.

### 3. Session deduplication in the funnel

AI suggested treating each ENTRY event as a new session.

**Decision**: Same session if a REENTRY event links the visitor_id. This avoids
inflating the funnel denominator with re-entries, which would understate conversion
rate — exactly the vendor problem the challenge asks us to solve.

---

*Last updated: June 2026*
