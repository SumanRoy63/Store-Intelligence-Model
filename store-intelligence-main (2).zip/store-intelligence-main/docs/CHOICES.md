# CHOICES.md — Architecture Decision Record

## Decision 1: Detection model — YOLOv8n + ByteTrack

### Options considered
- **YOLOv8n** (nano) — fastest, CPU tractable, ~80% mAP on COCO person class
- **YOLOv8x** (extra-large) — highest accuracy, ~4× slower, requires GPU >8GB VRAM
- **RT-DETR** — transformer-based, slightly better crowded scenes, complex setup
- **MediaPipe** — single-person focus, degrades with crowds

### AI suggestion
YOLOv8x for maximum accuracy (challenge scores on entry/exit count accuracy).
Extra inference time acceptable for offline batch processing.

### Decision and rationale
**YOLOv8n.** On CPU at 1080p, YOLOv8x processes ~0.3fps (20-min clip = hours).
YOLOv8n processes ~3fps, making the full dataset tractable in ~2 hours.
People at retail CCTV distances are large in-frame and well-lit — the accuracy
gap at this resolution is smaller than benchmark numbers suggest.

With a GPU available, switch to YOLOv8m: one-line change in `detect.py`.

---

## Decision 2: Event schema design

### Options considered
- **Flat schema** — all fields top-level
- **Nested metadata** — required fields + `metadata` object (spec schema)
- **Typed union** — separate Pydantic model per event type

### AI suggestion
Typed discriminated unions for stronger validation in Pydantic v2.

### Decision and rationale
**Nested metadata schema matching the spec exactly.** The challenge provides an
explicit required schema. Deviating would break compatibility with sample_events.jsonl
and assertions.py. Cross-field validators on the single schema achieve the same
safety (e.g. `BILLING_QUEUE_JOIN` requires `metadata.queue_depth`, zone events
require `zone_id`). Confidence is never suppressed — passed through at raw value.

---

## Decision 3: API — FastAPI + SQLite, single container

### Options considered
- **FastAPI + SQLite, single container** — chosen
- **FastAPI + PostgreSQL, two containers** — production-like, better concurrency
- **FastAPI + Redis + PostgreSQL** — full production stack with event queue
- **Flask + SQLite** — simpler, poor async support

### AI suggestion
FastAPI + PostgreSQL for production correctness. SQLite has write serialisation
under concurrent load and no parallel writes.

### Decision and rationale
**FastAPI + SQLite WAL, single container.** The only writer is `/events/ingest`,
called in sequential batches from the pipeline. WAL mode handles this cleanly.
Readers (`/metrics`, `/funnel`, etc.) run concurrently with the writer in WAL mode.

`docker compose up` starts everything with no manual steps. PostgreSQL would
require coordinating startup order, health checks, and migrations across two
containers — operational complexity with no benefit at this data scale.

---

*Decisions recorded in real time during implementation.*
