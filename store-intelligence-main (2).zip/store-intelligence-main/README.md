# Store Intelligence API

Real-time retail analytics from CCTV-derived events.
Built for **Purplle Tech Challenge 2026 — Round 2**.

---

## Quick Start — 3 steps

```bash
# 1. Start the API
docker compose up --build -d

# 2. Verify it's running
curl http://localhost:8000/health

# 3. Run the detection pipeline + ingest events
cd pipeline
pip install -r requirements.txt
python emit.py /path/to/clip.mp4 \
  --store-id STORE_BLR_001 \
  --camera-id CAM_01 \
  --layout layout.json \
  --clip-start 2026-06-01T09:00:00Z \
  --api-url http://localhost:8000 \
  --stride 3
```

---

## API Endpoints

| Method | Path                          | Description                              |
|--------|-------------------------------|------------------------------------------|
| `POST` | `/events/ingest`              | Ingest batch of up to 500 events         |
| `GET`  | `/stores/{id}/metrics`        | Real-time store metrics                  |
| `GET`  | `/stores/{id}/funnel`         | Conversion funnel with drop-off %        |
| `GET`  | `/stores/{id}/heatmap`        | Zone visit frequency heatmap (0–100)     |
| `GET`  | `/stores/{id}/anomalies`      | Active operational anomalies             |
| `GET`  | `/health`                     | Service health + per-store feed status   |

Interactive docs: http://localhost:8000/docs (development mode only)

---

## Project Structure

```
store-intelligence/
├── app/
│   ├── main.py              # FastAPI app entry point
│   ├── core/
│   │   ├── config.py        # Settings from .env
│   │   ├── database.py      # Async SQLite engine + session
│   │   ├── errors.py        # Error handlers
│   │   └── logging.py       # JSON logging + request middleware
│   ├── models/
│   │   ├── event.py         # Event ORM model
│   │   └── store_baseline.py
│   ├── routers/
│   │   ├── ingest.py        # POST /events/ingest
│   │   ├── stores.py        # GET /stores/{id}/...
│   │   └── health.py        # GET /health
│   ├── schemas/
│   │   └── events.py        # All Pydantic request/response models
│   └── services/
│       ├── ingestion.py     # Idempotent batch persist
│       ├── metrics.py       # Visitor/conversion/queue metrics
│       ├── funnel.py        # 4-stage conversion funnel
│       ├── heatmap.py       # Zone frequency heatmap
│       └── anomalies.py     # Queue spike / conversion drop / dead zone
├── pipeline/
│   ├── detect.py            # YOLOv8n person detection
│   ├── tracker.py           # ByteTrack + re-entry detection
│   ├── zones.py             # Polygon zone mapping
│   ├── emit.py              # Event builder + API POST
│   ├── layout.json          # Store zone polygons
│   └── requirements.txt     # Pipeline-only deps
├── tests/
│   ├── conftest.py          # In-memory DB + ASGI test client
│   ├── test_health.py
│   ├── test_ingest.py
│   └── test_metrics.py
├── docs/
│   ├── DESIGN.md            # Architecture + AI decision log
│   └── CHOICES.md           # 3 key decisions with full reasoning
├── alembic/                 # DB migrations
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── pytest.ini
```

---

## Running Tests

```bash
pip install -r requirements.txt
pytest
```

Coverage report written to `htmlcov/index.html`.

---

## Environment Variables

| Variable                        | Default                                          | Description                       |
|---------------------------------|--------------------------------------------------|-----------------------------------|
| `DATABASE_URL`                  | `sqlite+aiosqlite:///./data/store_intelligence.db` | DB connection string            |
| `LOG_LEVEL`                     | `INFO`                                           | Logging level                     |
| `ENVIRONMENT`                   | `development`                                    | `production` disables /docs       |
| `STALE_FEED_THRESHOLD_SECONDS`  | `600`                                            | Seconds before feed is flagged    |
| `DEAD_ZONE_THRESHOLD_SECONDS`   | `1800`                                           | Seconds before dead zone fires    |
| `BASELINE_CONVERSION_RATE`      | `0.35`                                           | Fallback if no DB baseline        |

---

## Known Limitations

- Staff classification (`is_staff`) is not implemented in the detection pipeline;
  the field is accepted and stored but always set to `false` by emit.py.
- Zone dwell analytics depend on ZONE_DWELL events; these require continued presence
  for ≥ 30s in the same zone to appear.
- Store layout (`layout.json`) must be manually calibrated per camera angle.
